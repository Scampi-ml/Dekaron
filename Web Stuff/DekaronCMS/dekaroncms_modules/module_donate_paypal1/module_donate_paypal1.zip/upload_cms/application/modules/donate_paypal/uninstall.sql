DROP TABLE `donate_paypal_transactions`;
DROP TABLE `donate_paypal_items`;
DELETE FROM `module_config` WHERE `key` = 'donate_paypal';