<?php
echo'
				</td>
			</tr>
		</table>
	</body>
</html>';
?>