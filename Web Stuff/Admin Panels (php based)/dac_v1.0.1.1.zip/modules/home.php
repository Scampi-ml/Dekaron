<?php
$current_version = @file_get_contents('engine/version.txt');
$new_version = @file_get_contents('http://www.dkunderground.org/dac_remote/version.js');
?>
<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" class="table_panel">
	<tr>
		<td align="center" class="panel_title" colspan="2">DAC Version</td>
	</tr>
	<tr>
		<td align="left" class="panel_title_sub" colspan="2">Current version</td>
	</tr>
	<tr>
		<td align="left" class="panel_text_alt1" width="45%" valign="top">Current DAC version.</td>
		<td align="left" class="panel_text_alt2" width="45%" valign="top">
			<?php
				if (version_compare($current_version, $new_version) >= 0)
				{
					echo 'I am at least version! (Version '.$$current_version.')';
				}
				else
				{
					echo '<blink><b>VERSION '.$new_version.' REQUIRED!</b></blink>';
				}
			?>
        </td>
	</tr>
</table>

<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" class="table_panel" style="margin-top: 20px;">
	<tr>
		<td align="center" class="panel_title" colspan="2">About DAC</td>
	</tr>
	<tr>
		<td align="left" class="panel_title_sub" colspan="2">Important Information</td>
	</tr>
	<tr>
		<td align="left" class="panel_text_alt1" width="45%" valign="top">
        <?php
			$remote_file = @file_get_contents('http://www.dkunderground.org/dac_remote/important_message.txt');
			if($remote_file != '')
			{
				echo '<p class="msg_error">'.$remote_file.'</p>';
			}
			else
			{
				echo '<br><i>No important messages.</i><br>';
			}
		?>
        </td>
	</tr>
</table>

