<?php
if (isset($_GET['admin']) && !empty($_GET['admin']))
{
	unlink(dirname(dirname(__FILE__)).DIRECTORY_SEPARATOR.'servers'.DIRECTORY_SEPARATOR.$_SESSION["server"].DIRECTORY_SEPARATOR.$_GET['admin'].DIRECTORY_SEPARATOR.'config.ini');
	unlink(dirname(dirname(__FILE__)).DIRECTORY_SEPARATOR.'servers'.DIRECTORY_SEPARATOR.$_SESSION["server"].DIRECTORY_SEPARATOR.$_GET['admin'].DIRECTORY_SEPARATOR.'permissions.ini');
	rmdir(dirname(dirname(__FILE__)).DIRECTORY_SEPARATOR.'servers'.DIRECTORY_SEPARATOR.$_SESSION["server"].DIRECTORY_SEPARATOR.$_GET['admin']);
	echo notice_message_admin('Admin successfully deleted', '1', '0', 'index.php?get=module_admins');
}
else
{
?>
<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0"  class="table_panel" >
    <tr>
    	<td align="center" class="panel_title" colspan="2">Admins</td>
    </tr>
	<tr> 
        <td align="left" class="panel_title_sub2">Account</td>
        <td align="left" class="panel_title_sub2">Action</td>  
	</tr> 
	<?php   
        flush_this(); 
        $count = 0;
		
		$directory = opendir('servers/'.$_SESSION["server"].'/');
		while ($admin = readdir($directory))
		{
			if ($admin != "." && $admin != ".." && $admin != 'logs' && $admin != 'index.html')
			{
				$count++;
				$tr_color = ($count % 2) ? '' : 'even';
				
				$tmp = explode(':', $val);
				
				echo "<tr class='" . $tr_color . "' >";
					echo "<td align='left' class='panel_text_alt_list' width='50%'>".htmlspecialchars($admin)."</td>";
					echo "<td align='left' class='panel_text_alt_list' width='50%'>";
					
					if(file_exists('servers/'.$_SESSION["server"].'/'.$admin.'/admin.txt')) 
					{
						echo "Main Admin (Cannot be edited)";
					}
					else
					{
						echo "
						<a href='index.php?get=module_admins&admin=".htmlspecialchars($admin)."'>Delete</a>&nbsp;&nbsp;
						<a href='index.php?get=module_admin_permissions&admin=".htmlspecialchars($admin)."'>Permissions</a></td>";
					}
				echo "</tr>"; 					
			}
		}
    ?>
</table>
<br>
<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" >
    <tr>
    	<td><p class="msg_error"><blink>NOTE:</blink> This will remove the user's settings & permissions, but not the mssql login!</p></td>
    </tr>
</table>
<?php
}
?>