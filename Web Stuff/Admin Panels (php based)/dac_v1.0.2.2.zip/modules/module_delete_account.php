<?php
if (isset($_POST) && !empty($_POST))
{
		$db->SQLquery("DELETE FROM account.dbo.user_profile  WHERE user_no = '%s'", $_POST['account']);
		
		$db->SQLquery("DELETE FROM user_cash.dbo.cash WHERE user_no = '%s'", $_POST['account']);
		$db->SQLquery("DELETE FROM user_charge_log.dbo.cash WHERE user_no = '%s'", $_POST['account']);
		$db->SQLquery("DELETE FROM user_use_log.dbo.cash WHERE user_no = '%s'", $_POST['account']);
	
		$delete_this_also = $_POST['also_delete'];
		foreach($delete_this_also as $char)
		{
			$db->SQLquery("DELETE FROM character.dbo.user_character WHERE character_no = '%s'", $char);
		
			$db->SQLquery("DELETE FROM character.dbo.User_Quest_Done WHERE character_no = '%s'", $char);
			$db->SQLquery("DELETE FROM character.dbo.User_Quest_Doing WHERE character_no = '%s'", $char);
			$db->SQLquery("DELETE FROM character.dbo.user_bag WHERE character_no = '%s'", $char);
			$db->SQLquery("DELETE FROM character.dbo.USER_POSTBOX WHERE character_no = '%s'", $char);
			$db->SQLquery("DELETE FROM character.dbo.user_storage WHERE character_no = '%s'", $char);
			$db->SQLquery("DELETE FROM character.dbo.user_skill WHERE character_no = '%s'", $char);
			$db->SQLquery("DELETE FROM character.dbo.user_slot WHERE character_no = '%s'", $char);
			$db->SQLquery("DELETE FROM character.dbo.user_storage WHERE character_no = '%s'", $char);
			$db->SQLquery("DELETE FROM character.dbo.user_suit WHERE character_no = '%s'", $char);
	}
	echo notice_message_admin('Account successfully deleted', '1', '0', 'index.php?get=module_search_account');
}
else
{
	flush_this();
	$SQLquery1 = $db->SQLquery("SELECT user_no,user_id FROM account.dbo.user_profile WHERE user_no = '%s'", $_GET['account']);
	$getAccountInfo = $db->SQLfetchArray($SQLquery1);
	
	$SQLquery2 = $db->SQLquery("SELECT character_no,character_name,user_no FROM character.dbo.user_character WHERE user_no = '%s'", $_GET['account']);
?>
<form action="" method="post">
<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" class="border">
    <tr>
        <td class="cat"><div align="left"><b>Please confirm</b></div></td>
    </tr>
    <tr>
        <td align="center" style="padding-top: 20px; padding-bottom: 20px;">
        	<b>Are you sure you want to delete account "<?php echo $getAccountInfo['user_id']; ?>" ?</b>
            <br>
            <br>
            <?php
			flush_this();
			while($getCharacterInfo = $db->SQLfetchArray($SQLquery2))
			{
				echo '<p class="msg_error"><input type="checkbox" name="also_delete[]" checked value="'.$getCharacterInfo['character_no'].'">Character: '.$getCharacterInfo['character_name'].'</p>';
			}
			?>
        	<br><br>This action cannot be undone!
            <br>
            Deleting character(s) will also delete all of there info, quests, inventory, skills, ... ect
            <br><br><br>
            <input type="hidden" name="account" value="<?php echo $getAccountInfo['user_no']; ?>" >
        	<input type="submit" value="Delete account" onclick="ask_url('Are you sure you want to delete this account?','index.php?get=module_delete_account')">
    	</td> 
    </tr>
</table>	
</form>	
<?php
}
?>