<?php
flush_this();
$SQLquery1 = $db->SQLquery("SELECT * FROM master.dbo.sysxlogins");
$qnum1 = $db->SQLfetchNum($SQLquery1);
?>
<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0"  class="table_panel" >
    <tr>
    	<td align="center" class="panel_title" colspan="3">Admins</td>
    </tr>
	<tr> 
        <td align="left" class="panel_title_sub2">Admin Name</td>
        <td align="left" class="panel_title_sub2">Created</td>
        <td align="left" class="panel_title_sub2">Permissions</td>  
	</tr> 
	<?php   
	if ($qnum1 == '0')
	{
		echo '<tr><td align="center" class="panel_text_alt_list" colspan="5">No admin found ???????? This cannot happen!</td></tr>';
	}
	else
	{
		flush_this();
		$count = 0;
		while ($record = $db->SQLfetchArray($SQLquery1)) 
		{ 
			$count++;
			$tr_color = ($count % 2) ? '' : 'even';
			
			if($record['xstatus'] == '192')
			{
				continue;
			}
			echo "<tr class='" . $tr_color . "' > 
					<td align='left' class='panel_text_alt_list'>".htmlspecialchars($record['name'])."</td> 
					<td align='left' class='panel_text_alt_list'>".htmlspecialchars($record['xdate1'])."</td>
					<td align='center' class='panel_text_alt_list'>
			";
			if(file_exists('servers/'.$_SESSION["server"].'/'.$record['name'].'/admin.txt') || $record['xstatus'] == '22') 
			{
				echo "( Cannot edit )</td>";
			}
			else
			{	
				echo "<a href='index.php?get=module_admin_permissions&admin=".htmlspecialchars($record['name'])."'>Permissions</a></td>";
			}		
			echo "</tr>"; 
		}
	}
    ?>
</table>
<br>
<p class="msg_error" style="width:95%;">Please use, "Enterprise Manager" to edit / create / delete accounts.</p>