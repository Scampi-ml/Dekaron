<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" class="border_big" style="height: 60px;">
	<tr>
		<td class="cat_big" valign="top">
			<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
				<tr>
                	<td align="left"><h3>Dekaron Admin Control</h3></td>
					<td align="right"><a href="index.php?get=home" target="body">Admin Home</a> | <a href="index.php?get=logout" target="_top">Log Out</a></td>
				</tr>
			</table>
		</td>
	</tr>
</table>