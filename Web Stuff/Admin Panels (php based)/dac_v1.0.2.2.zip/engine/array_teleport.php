<?php
//Count , Map Id , Map Name , Map Pos. X , Map Pos. Y

$array_teleport = array(
	'0' => array("0","Braiken Castle","294","245"),
	'1' => array("1","North Ares","296","185"),
	'2' => array("2","Den of Norak","0","0"),
	'3' => array("3","Denebe","467","274"),
	'4' => array("6","Parca","418","324"),
	'5' => array("7","Loa Castle","275","221"),
	'6' => array("12","Crespo","136","306"),
	'7' => array("13","Draco Desert","221","193"),
	'8' => array("17","Requies Beach","46","466"),
	'9' => array("18","Avalon Island","426","373"),
	'10' => array("23","Genoa Castle","71","287"),
	'11' => array("61","Braiken Agency","255","281"),
	'12' => array("62","Loa Agency","255","281"),
	'13' => array("65","Plane of Pilgrimage","150","350"),
	'14' => array("99","Crash Map","280","220")
);


?>