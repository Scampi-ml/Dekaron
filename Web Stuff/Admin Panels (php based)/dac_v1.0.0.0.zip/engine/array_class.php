<?php
$array_class = array(
	'0' => 'Azure Knight', 
	'1' => 'Segita Hunter', 
	'2' => 'Incar Magician', 
	'3' => 'Vicious Summoner', 
	'4' => 'Segnale', 
	'5' => 'Bagi Warrior', 
	'6' => 'Aloken',
	'10' => 'Concerra Summoner',
	'11' => 'Seguriper'
); 

?>