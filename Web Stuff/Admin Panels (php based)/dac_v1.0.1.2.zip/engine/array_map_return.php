<?php

// Here are predefined locations for your server
// These locations can be set as new RETURN LOCATIONS, like return statues
// These X and Y coordinated are based on VERSION,EU-18.0.3

// -------------------------------
//         NOT IN USE!
// -------------------------------

$array_map_return = array(

'0' => array("0","Braiken Castle","294","245"),
'1' => array("1","North Ares","296","185"),
'2' => array("3","Denebe","467","274"),
'3' => array("6","Parca","418","324"),
'4' => array("7","Loa Castle","275","221"),
'5' => array("12","Crespo","136","306"),
'6' => array("13","Draco Desert","221","193"),
);

?>