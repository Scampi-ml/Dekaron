EXEC SP_POST_SEND_OP2 'G12080530000000007', 'Janvier DB', '1', 'Test DB Send', 'Send from DB','60008', '0', '6', '0'


/// INFO HERE
@i_character_no
@i_from_char_nm
@i_post_sort
@i_post_title
@i_body_text
@i_wIndex
@i_include_dil
@i_days
@o_sp_rtn