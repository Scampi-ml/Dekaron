<?php
/**
 * Proxy file for the actual smarty library. This file exists because the autoloader loads classname.php (see bootstrap.php)
 */
    include('smarty/libs/Smarty.class.php');
?>
