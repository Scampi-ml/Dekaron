<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
		<title> vote for coins</title>
		<style type="text/css">
			div#container
			{
			   width: 350px;
			   position: relative;
			   margin-top: 0px;
			   margin-left: auto;
			   margin-right: auto;
			   text-align: left;
			}
			body
			{
			   text-align: center;
			   margin: 0;
			}
		</style>
	</head>
	<body bgcolor="#202020" text="#FFD700">
		<div id="wb_Text1" style="position:absolute;left:10px;top:120px;width:240px;height:14px;z-index:0;" align="left">
			<font style="font-size:11px" color="#ffffff" face="Arial">You can vote every 12 hours. 1 vote = 25 coins</font>
        </div>
						<img src="http://www.xtremeTop100.com/votenew.jpg" border="0" alt="Dekaron Servers" style="position:absolute;left:250px;top:34px; >
        <div id="container">
            <div id="wb_Form1" style="position:absolute;left:0px;top:0px;width:239px;height:135px;z-index:3;" align="left">
                   <form name="Form1" method="post" action="vote.php" id="Form1">
                        <div id="wb_Text1" style="position:absolute;left:10px;top:15px;width:78px;height:14px;z-index:0;" align="left">
                            <font style="font-size:11px" color="#FFD700" face="Arial">Account name:</font></div>
                        <input type="text" id="Editbox1" style="position:absolute;left:10px;top:34px;width:200px;font-family:Courier New;font-size:16px;z-index:1" name="account" value="">
                        <input type="submit" id="Button1" name="Button1" value="Vote" style="position:absolute;left:10px;top:65px;width:96px;height:25px;font-family:Arial;font-size:13px;z-index:2">
                    </form>
                </div>
            </div>
		</div>
	</body>
</html>