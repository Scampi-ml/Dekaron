<?php
// FOR LIVE SITE ONLY!
include ('../evo_config.php');
date_default_timezone_set("America/Chicago");

$CONFIG['UCP_DISABLED'] = "false";
$CONFIG['UCP_DISABLED_MSG'] = "Offline for maintenace.";
$CONFIG['UCP_VERSION'] = "5";
?>

		