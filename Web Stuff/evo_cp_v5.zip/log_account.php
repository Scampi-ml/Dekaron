<?php
include ('header.php');
include ('sidebar.php');
?>
<section class="main-section grid_7">
    <div class="main-content">
        <header>
            <h2>Account Log</h2>
        </header>
        <section class="container_6 clearfix">
            <div class="grid_6">
                <table class="datatable paginate sortable full" align="center">
                    <thead>
                        <tr>
                            <th>Login</th>
                            <th>Logout</th>
                            <th>Ip Adress</th>
                        </tr>
                    </thead>
                    <tbody>

                    <?php $dekaron->flushthis(); ?>                    
                    <?php
                        $query2 = $dekaron->SQLquery("SELECT TOP 100 conn_no,user_no,login_time,logout_time,conn_ip FROM account.dbo.USER_CONNLOG_KEY WHERE user_no = '".$_SESSION['USERNO']."' ORDER BY conn_no DESC");
                        while ( $getLog2 = $dekaron->SQLfetchArray($query2) ) 
                        {
                            echo "<tr>";
                            echo '<td align="center">'.$getLog2['login_time'].'</td>';
                            echo '<td align="center">'.$getLog2['logout_time'].'</td>';
                            echo '<td align="center">'.$dekaron->decodeIp($getLog2['conn_ip']).'</td>';
                            echo "</tr>";
                        }
                    ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</section>
<?php include ('footer.php'); ?>